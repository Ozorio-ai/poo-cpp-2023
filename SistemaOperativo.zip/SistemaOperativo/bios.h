class Bios{
	public:
		OperatingSystem os;
		Bios();
};
Bios::Bios(){
	ifstream get;
	string usrnm, country, psswd;
	get.open("Administrador.txt", ios::in | ios::binary);
	if(!get){
		get.close();
		ofstream store;	
		os.adminController.wellcomingUser();
		wellcome_message();
		store.open("Administrador.txt", ios::app | ios::binary);
		if(!store){
			cout<<"\t\tALGUM ERRO OCORREU..."<<endl;
		}else{
			cout<<"\t\tINFORME AS SUAS SUAS CREDENCIAIS"<<endl;
			cout<<"\t\t================================"<<endl<<endl;
			cout<<"\t\tNOME DO USUARIO ---- : ";
			getline(cin, usrnm);
			cout<<"\t\tPAIS --------------- : ";
			cin>>country;
			cout<<"\t\tSENHA -------------- : ";
			cin>>psswd;
			os.admin.setUserId(1);
			os.admin.setUserKey(8252);
			os.admin.setName(usrnm);
			os.admin.setCountry(country);
			os.admin.setPassword(psswd);
			store.write((char*)&os.admin, sizeof(os.admin));
			cout<<endl<<"\t\tOPERACAO EFECTUADA COM SUCESSO...";
			sleep(3);
		}
		store.close();
	}
	get.close();	
	os.shooseUserToLogin();
}