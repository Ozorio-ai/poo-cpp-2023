class Program{
	private:
		int programId;
		string name, version;
		float usedSpace;
	public:
		void setProgramId(int);
		int getProgramId();
		void setName(string);
		string getName();
		void setVersion(string);
		string getVersion();
		void setUsedSpace(float);
		float getUsedSpace();
};
void Program::setProgramId(int id){
	this->programId = id;
}
int Program::getProgramId(){
	return this->programId;
}
void Program::setName(string nm){
	this->name = nm;
}
string Program::getName(){
	return this->name;
}
void Program::setVersion(string vrsn){
	this->version = vrsn;
}
string Program::getVersion(){
	return this->version;
}
void Program::setUsedSpace(float usdSpc){
	this->usedSpace = usdSpc;
}
float Program::getUsedSpace(){
	return this->usedSpace;
}