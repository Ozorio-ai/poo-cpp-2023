class User{
	private:
		int userId, userKey;
		string name;
		string password;
	public:
		User();
		void setUserId(int);
		int getUserId();
		void setUserKey(int);
		int getUserKey();
		void setName(string);
		string getName();
		void setPassword(string);
		string getPassword();
};
User::User(){
	this->setPassword("");
	this->setName("User");
}
void User::setUserId(int usrId){
	this->userId = usrId;
}
void User::setUserKey(int usrKy){
	this->userKey = usrKy;
}
int User::getUserKey(){
	return this->userKey;
}
int User::getUserId(){
	return this->userId;
}
void User::setName(string nm){
	this->name = nm;
}
string User::getName(){
	return this->name;
}
void User::setPassword(string psswd){
	this->password = psswd;
}
string User::getPassword(){
	return this->password;
}