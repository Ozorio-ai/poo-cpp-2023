using namespace std;
#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif
#include <fstream>
#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include <string>
#include <dos.h>
#include "mylibrary.h"
#include "user.h"
#include "administrator.h"
#include "program.h"
#include "admincontroller.h"
#include "usercontroller.h"
#include "programcontroller.h"
#include "operatingsystem.h"
#include "bios.h"

int main() {
	Bios bios;
	return 0;
}