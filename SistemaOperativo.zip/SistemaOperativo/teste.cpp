#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif
 
#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;
int main()
{
	string name;
	cout<<"Insira o seu nome: ";
	getline(cin, name);
	cout<<"Nome: "<<name<<endl;
}