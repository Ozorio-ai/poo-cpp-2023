#ifndef SISTEMAOPERATIVO_H
#define SISTEMAOPERATIVO_H

class OperatingSystem: public Program{
	public:
		//Controllers Objects instances
		AdminController adminController;
		UserController userController;
		ProgramController programController;
		//Users Objects instances
		Admin admin;
		User user;
		Program program;
		//Methods
		void allUsers();
		int listAllUsers();
		void createUser();
		void performAdminMenu();
		void performUserMenu();
		//Views Methods
		void shooseUserToLogin();
		void adminLoginView();
		void userLoginView(int);
		int upAppStore();
		void installedApps();
		void installAplication();
		void appInstaler(string, float, string, int);
};
void OperatingSystem::allUsers(){
	ifstream getAdmin, getUser;
	int countUsers = 1;
	cout<<"\t\tUSUARIOS DO SISTEMA"<<endl;
	cout<<"\t\t==================="<<endl;
	getAdmin.open("Administrador.txt", ios::in | ios::binary);
	if(!getAdmin){
		error();
	}else{
		getAdmin.read((char*)&admin, sizeof(admin));
		while(!getAdmin.eof()){
			cout<<"\t\t["<<countUsers<<"]. "<<admin.getName()<<endl;
			getAdmin.read((char*)&admin, sizeof(admin));
			countUsers++;
		}
	}
	getAdmin.close();
	getUser.open("Usuarios.txt", ios::in | ios::binary);
	if(getUser){
		getUser.read((char*)&user, sizeof(user));
		while(!getUser.eof()){
			cout<<"\t\t["<<countUsers<<"]. "<<user.getName()<<endl;
			getUser.read((char*)&user, sizeof(user));
			countUsers++;
		}
	}
	cout<<"\t\t[0]. DESLIGAR"<<endl;
	getUser.close();
}
int OperatingSystem::listAllUsers(){
	int option;
	this->allUsers();
	cout<<endl<<"\t\tUSUARIO ----- : ";
	cin>>option;
	return option;
}
void OperatingSystem::createUser(){
	ofstream store;
	ifstream get;
	string usrnm, psswd;
	int qttyUsers = 1;
	os_name();
	store.open("Usuarios.txt", ios::app | ios::binary);
	if(!store){
		cout<<"\t\tALGUM ERRO OCORREU..."<<endl;
	}else{
		get.open("Usuarios.txt", ios::in | ios::binary);
		if(get){
			get.read((char*)&user, sizeof(user));
			while(!get.eof()){
				qttyUsers++;
				get.read((char*)&user, sizeof(user));
			}
		}
		get.close();
		if(qttyUsers <= 3){
			cout<<"\t\tINFORME AS SUAS SUAS CREDENCIAIS"<<endl;
			cout<<"\t\t================================"<<endl<<endl;
			cout<<"\t\tNOME DO USUARIO ---- : ";
			cin>>usrnm;
			cout<<"\t\tSENHA -------------- : ";
			cin>>psswd;
			user.setUserId(qttyUsers);
			user.setUserKey(844894122);
			user.setName(usrnm);
			user.setPassword(psswd);
			store.write((char*)&user, sizeof(user));
			cout<<endl<<"\t\tOPERACAO EFECTUADA COM SUCESSO...";	
		}else{
			cout<<"\t\tEXCEDEU O LIMITE DE USUARIOS NO SISTEM..."<<endl;
		}
		sleep(3);
	}
	store.close();
}
void OperatingSystem::performAdminMenu(){
	int option = 1;
	do{
		os_name();
		switch(adminController.adminInterface()){
			case 0:
				option = 0;
			break;
			case 1:
				this->installedApps();
			break;
			case 2:
				os_name();
				this->allUsers();
				cout<<"\t\tPressione qualquer tecla para continua...";
				getch();
			break;
			case 3:
				this->installAplication();
			break;
			case 4:
				system("explorer .");
			break;
			case 5:
				this->upAppStore();
			break;
			case 6:
				this->createUser();
			break;
		}
	}while(option == 1);
	this->shooseUserToLogin();
}
void OperatingSystem::performUserMenu(){
	int option = 1;
	do{
		os_name();
		switch(userController.userInterface()){
			case 0:
				option = 0;
			break;
			case 1:
				this->installedApps();
			break;
			case 2:
				this->installAplication();
			break;
			case 3:
				system("explorer .");
			break;
			case 4:
				this->upAppStore();
			break;
		}
	}while(option == 1);
	this->shooseUserToLogin();
}
//Views Methods
void OperatingSystem::shooseUserToLogin(){
	os_name();
	switch(this->listAllUsers()){
		case 0:
			for(int i = 0; i < 3; i++){
				system("cls");
				cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<"\t\t\t\t\tDESLIGANDO";
				loading();
			}
		break;
		case 1:
			this->adminLoginView();
		break;
		case 2:
			this->userLoginView(2);
		break;
		case 3:
			this->userLoginView(3);
		break;	
		case 4:
			this->userLoginView(4);
		break;
	}
}

void OperatingSystem::adminLoginView(){
	ifstream get;
	string psswd;
	int countChances = 4;
	do{
		os_name();
		get.open("Administrador.txt", ios::in | ios::binary);
		if(!get){
			error();
		}else{
			get.read((char*)&admin, sizeof(admin));
			cout<<"\t\t\t\t\t|===================|"<<endl;
			cout<<"\t\t\t\t\t\t"<<admin.getName()<<endl;
			cout<<"\t\t\t\t\t|===================|"<<endl<<endl;
			get.read((char*)&admin, sizeof(admin));
		}
		get.close();
		cout<<"\t\tPASSWORD ----- : ";
		cin>>psswd;
		if(!adminController.login(psswd)){
			cout<<"\t\tSENHA INCORRECTA . . .";
			sleep(2);
			countChances--;
		}
	}while(!adminController.login(psswd) && countChances);
	if(adminController.login(psswd)){
		this->performAdminMenu();    
	}else{
		this->shooseUserToLogin();
	}
}
void OperatingSystem::userLoginView(int usrId){
	ifstream get;
	string psswd;
	int countUsers = 2, countChances = 4;
	
	do{
		os_name();
		get.open("Usuarios.txt", ios::in | ios::binary);
		if(!get){
			error();
		}else{
			get.read((char*)&user, sizeof(user));
			while(!get.eof()){
				if(countUsers == usrId){
					cout<<"\t\t\t\t\t|===================|"<<endl;
					cout<<"\t\t\t\t\t      "<<user.getName()<<endl;
					cout<<"\t\t\t\t\t|===================|"<<endl<<endl;	
					break;
				}	
				countUsers++;
				get.read((char*)&user, sizeof(user));
			}
		}
		get.close();
		cout<<"\t\tPASSWORD ----- : ";
		cin>>psswd;
		if(!userController.login(psswd)){
			cout<<"\t\tSENHA INCORRECTA . . .";
			sleep(2);
			countUsers = 2;
			countChances--;
		}
	}while(!userController.login(psswd) && countChances);
	if(userController.login(psswd)){
		this->performUserMenu();    
	}else{
		this->shooseUserToLogin();
	}
}
int OperatingSystem::upAppStore(){
	int option;
	for(int i = 0; i < 3; i++){
		cout<<endl<<endl<<endl<<endl<<endl<<endl<<endl<<"\t\t\tCARREGANDO A LOJA DE APLICATIVOS";
		loading();
	}
	up_app_strore_name();
	cout<<"\t\tAPLICACOES DISPONIVEIS NA LOJA"<<endl;
	cout<<"\t\t=============================="<<endl<<endl;
	cout<<"\t\t[1]. |===================|\t[2]. |===================|"<<endl;
	cout<<"\t\t     |       VS Code     |\t     |    Calculadora    |"<<endl;
	cout<<"\t\t     |===================|\t     |===================|"<<endl;
	cout<<"\t\t     Tamanho: 30.5MB      \t     Tamanho: 10.6MB"<<endl;
	cout<<"\t\t     Versao: 10.5         \t     Versao: 6.0.4"<<endl<<endl;

	cout<<"\t\t[3]. |===================|\t[4]. |===================|"<<endl;
	cout<<"\t\t     |      MS Edge      |\t     |      UPOffice     |"<<endl;
	cout<<"\t\t     |===================|\t     |===================|"<<endl;
	cout<<"\t\t     Tamanho: 98.9MB      \t     Tamanho: 300.9MB"<<endl;
	cout<<"\t\t     Versao: 20.0.4       \t     Versao: 20.1"<<endl<<endl;
	cout<<endl<<"\t\tESCOLHA A APLICACAO A INSTALAR: ";
	cin>>option;
	return option;
}
void OperatingSystem::installedApps(){
	ifstream get;
	int count = 1, option;
	os_name();
	get.open("aplicativos.txt", ios::in | ios::binary);
	if(!get){
		cout<<"\t\tNENHUMA APLICACAO INSTALADA"<<endl;
	}else{
		cout<<"\t\tAPLICACOES INSTALADAS"<<endl;
		cout<<"\t\t====================="<<endl<<endl;
		get.read((char*)&program, sizeof(program));
		while(!get.eof()){
			cout<<"\t\t["<<program.getProgramId()<<"]. "<<program.getName()<<endl;
			count++;
			get.read((char*)&program, sizeof(program));
		}
		cout<<"\t\t[0]. VOLTAR"<<endl;
		get.close();
		cout<<endl<<"\t\tESCOLHA A APLICACAO A EXECUTAR: ";
		cin>>option;
		switch(option){
			case 1:
				system("code .");
			break;
			case 2:
				system("calc");
			break;
			case 3:
				system("ms edge");
			break;
			case 0:
				cout<<"\t\tVOLTANDO..."<<endl;
				sleep(2);
			break;
		}
	}
}
void OperatingSystem::installAplication(){
	switch(this->upAppStore()){
		case 1: this->appInstaler("VSCode", 30.5, "10.5", 1); break;
		case 2: this->appInstaler("Calculadora", 10.6, "6.0.4", 2); break;
		case 3: this->appInstaler("UPEdge", 98.9, "20.0.4", 3); break;
		case 4: this->appInstaler("UPOffice", 300.9, "20.1", 4); break;
	}
}
void OperatingSystem::appInstaler(string appName, float space, string version, int id){
	ofstream store;
	cout<<"\t\tDOWNLOADING: [";
	for(int i = 0; i < 7; i++){
		cout<<"===";
		sleep(2);
	}
	cout<<"]"<<endl;
	cout<<endl<<"\t\tDOWNLOAD EFECTUADO COM SUCESSO. \n\t\tCLIQUE QUALQUER TECLA PARA PROCESSEGUIR COM A INSTALACAO . . ."<<endl;
	getch();
	store.open("aplicativos.txt", ios::app | ios::binary);
	if(!store){
		cout<<"\t\tALGUM ERRO OCORREU..."<<endl;
	}else{
		cout<<endl<<endl<<"\t\tINSTALANDO";
		for(int j = 1; j <= 4; j++){
			cout<<".";
			sleep(1);
		}
		program.setName(appName);
		program.setUsedSpace(space);
		program.setProgramId(id);
		program.setVersion(version);
		store.write((char*)&program, sizeof(program));
		cout<<endl<<endl<<"\t\tAPLICACAO INSTALADA COM SUCESSO. PRESSIONE QUALQUER TECLA PARA CONTINUAR..."<<endl;
		getch();
	}
	store.close();
}
	

#endif