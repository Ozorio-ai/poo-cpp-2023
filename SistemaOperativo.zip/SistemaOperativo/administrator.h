class Admin: public User{
	private:
		string country;
	public:
		Admin(): User(){}
		void setCountry(string);
		string getContry();
};
void Admin::setCountry(string cntry){
	this->country = cntry;
}
string Admin::getContry(){
	return this->country;
}