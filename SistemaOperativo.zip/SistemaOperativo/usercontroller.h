class UserController{
	private:
		User user;
	public:
		int login(string);
		int userInterface();
};
int UserController::login(string psswd){
	ifstream get;
	int status = 0;
	get.open("Usuarios.txt", ios::in | ios::binary);
	if(get){
		get.read((char*)&user, sizeof(user));
		while(!get.eof()){
			if(psswd == user.getPassword()){
				status = 1;
				break;
			}
			get.read((char*)&user, sizeof(user));
		}
	}
	return status;
}
int UserController::userInterface(){
	int option;
	cout<<"\t\t[1]. APLICACOES\n\t\t[2]. INSTALAR APLICACAO\n\t\t[3]. GESTOR DE ARQUIVOS\n\t\t[4]. UPAppStrore\n\t\t[0]. LOGOUT\n\n\t\tESCOLHA A OPCAO: ";
	cin>>option;
	return option;
}