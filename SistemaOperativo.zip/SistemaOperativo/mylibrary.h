void loading(){
	for(int j = 1; j <= 4; j++){
		cout<<".";
		sleep(1);
	}
	system("cls");
}
void os_name(){
	system("cls");
	cout<<endl<<endl<<endl<<endl<<"\t\t---------------------------- UPOSystem ----------------------------"<<endl<<endl;
}
void up_app_strore_name(){
	system("cls");
	cout<<endl<<"\t\t---------------------- UPAppStrore ----------------------"<<endl<<endl;
}
void error(){
	cout<<"\t\tALGUM ERRO OCORREU..."<<endl;
}
void wellcome_message(){
	system("cls");
	cout<<endl<<endl<<endl<<endl<<"\t\t------------------ SEJA BEM VINDO AO SISTEM UPOSystem ------------------"<<endl<<endl;
}