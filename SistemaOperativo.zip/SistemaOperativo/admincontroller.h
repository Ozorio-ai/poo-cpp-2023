class AdminController{
	private:
		Admin admin;
		User user;
	public:
		void wellcomingUser();
		void setAdminCredentials();
		void setUserCredentials();
		void createAdmin();
		void createUser();
		int login(string);
		int adminInterface();
};

void AdminController::wellcomingUser(){
	for(int i= 1; i <= 3; i++){
		wellcome_message();
		cout<<"\t\t\t\t\t\tLoading";
		loading();
	}
	wellcome_message();
	cout<<"\t\tVOCE ESTA INICIANDO O SISTEM PELA PRIMEIRA VEZ. ISTO PODE LEVAR ALGUNS MINUTOS";
	sleep(2);
}
void AdminController::setAdminCredentials(){
	string usrnm, country, psswd;
	cout<<"\t\tINFORME AS SUAS SUAS CREDENCIAIS"<<endl;
	cout<<"\t\t================================"<<endl<<endl;
	cout<<"\t\tNOME DO USUARIO ---- : ";
	cin>>usrnm;
	cout<<"\t\tPAIS --------------- : ";
	cin>>country;
	cout<<"\t\tSENHA -------------- : ";
	cin>>psswd;
	admin.setUserId(1);
	admin.setUserKey(8252);
	admin.setName(usrnm);
	admin.setCountry(country);
	admin.setPassword(psswd);
}
void AdminController::setUserCredentials(){
	string usrnm, psswd;
	int qttyUsers = 1;
	ifstream get;
	get.open("Usuarios.txt", ios::in | ios::binary);
	if(get){
		get.read((char*)&user, sizeof(user));
		while(!get.eof()){
			qttyUsers++;
			get.read((char*)&user, sizeof(user));
		}
	}
	get.close();
	cout<<"\t\tINFORME AS SUAS SUAS CREDENCIAIS"<<endl;
	cout<<"\t\t================================"<<endl<<endl;
	cout<<"\t\tNOME DO USUARIO ---- : ";
	cin>>usrnm;
	cout<<"\t\tSENHA -------------- : ";
	cin>>psswd;
	user.setUserId(qttyUsers);
	user.setUserKey(844894122);
	user.setName(usrnm);
	user.setPassword(psswd);
}
void AdminController::createAdmin(){
	ofstream store;
	this->wellcomingUser();
	wellcome_message();
	
	store.open("Administrador.txt", ios::app | ios::binary);
	if(!store){
		cout<<"\t\tALGUM ERRO OCORREU..."<<endl;
	}else{
		this->setAdminCredentials();
		store.write((char*)&admin, sizeof(admin));
		cout<<endl<<"\t\tOPERACAO EFECTUADA COM SUCESSO...";
		sleep(3);
	}
	store.close();
}
void AdminController::createUser(){
	ofstream store;
	string nm, psswd;
	os_name();
	store.open("Usuarios.txt", ios::out | ios::binary);
	if(!store){
		cout<<"\t\tALGUM ERRO OCORREU..."<<endl;
	}else{
		this->setUserCredentials();
		store.write((char*)&user, sizeof(user));
		cout<<endl<<"\t\tOPERACAO EFECTUADA COM SUCESSO...";
		sleep(3);
	}
	store.close();
	getch();
}
int AdminController::login(string psswd){
	ifstream get;
	bool status = false;
	get.open("Administrador.txt", ios::in | ios::binary);
	if(get){
		get.read((char*)&admin, sizeof(admin));
		while(!get.eof()){
			if(psswd == admin.getPassword()){
				status = true;
				break;
			}
			get.read((char*)&admin, sizeof(admin));
		}
	}
	get.close();
	return status;
}
int AdminController::adminInterface(){
	int option;
	cout<<"\t\t[1]. APLICACOES INSTALADAS\n\t\t[2]. LISTA DE USUARIOS\n\t\t[3]. INSTALAR APLICACAO\n\t\t[4]. GESTOR DE ARQUIVOS\n\t\t[5]. UPAppStrore\n\t\t[6]. CRIAR NOVO USUARIO\n\t\t[0]. LOGOUT\n\n\t\tESCOLHA A OPCAO: ";
	cin>>option;
	system("cls");
	return option;
}